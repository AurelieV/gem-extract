const title = document.querySelector('h1');
if (title) {
    document.title = title.innerText;
}
